from abc import ABC, abstractmethod
import pandas as pd
import numpy as np
from scipy.stats import norm, chi2

from sklearn.linear_model import LinearRegression as lr
from sklearn.feature_selection import f_regression as fr

from .dependency_measures import DependenceMeasures, PartialCorrelation, LinearRegressionCoefficient, Gsq, CMIh, KernelPartialCorrelation


class CiTests(DependenceMeasures, ABC):
    def __init__(self, x, y, cond_list=None, drop_na=False):
        # Ensure DependenceMeasures is initialized with the same args
        super().__init__(x, y, cond_list, drop_na)
        self.x = x
        self.y = y
        if cond_list is None:
            self.cond_list = []
        else:
            self.cond_list = cond_list
        self.drop_na = drop_na


    @abstractmethod
    def get_pvalue(self, df):
        pass

    def get_pvalue_by_permutation(self, df, n_permutations: int = 1000, seed: int = None):
        """
        Generic permutation-based p-value estimator for conditional independence tests.

        Procedure (Monte-Carlo):
        - Prepare the data via _prepare_data.
        - Compute the observed dependence statistic via get_dependence.
        - For each permutation: permute the values of X (stratified within conditioning set if present),
          recompute the dependence statistic on the permuted dataset.
        - Compute the p-value as (count_perm_ge_obs + 1) / (n_permutations + 1) (to avoid zero p-values).

        Args:
            df (pd.DataFrame): data frame with the variables.
            n_permutations (int): number of permutations to perform (default 1000).
            seed (int): optional random seed for reproducibility.

        Returns:
            float: estimated p-value (or np.nan if test statistic cannot be computed).
        """
        df_pre = self._prepare_data(df)

        # Need sufficient samples
        if df_pre.shape[0] <= 1:
            return np.nan

        # observed statistic
        try:
            obs = self.get_dependence(df_pre)
        except Exception:
            return np.nan

        if obs is None or (isinstance(obs, float) and np.isnan(obs)):
            return np.nan

        obs_val = abs(obs)

        rng = np.random.default_rng(seed)
        X_orig = df_pre[self.x].values
        n = len(X_orig)

        count = 0
        # Precompute group indices if conditioning set present
        if self.cond_list:
            try:
                groups = df_pre.groupby(self.cond_list).indices
            except Exception:
                # fallback to no stratification
                groups = None
        else:
            groups = None

        for _ in range(n_permutations):
            permuted_x = np.empty_like(X_orig)
            if groups and len(groups) > 0:
                # Permute within each group
                permuted_x[:] = X_orig
                for _, idx in groups.items():
                    if len(idx) <= 1:
                        continue
                    permuted_x[idx] = X_orig[np.array(idx)[rng.permutation(len(idx))]]
            else:
                permuted_x = X_orig[rng.permutation(n)]

            df_perm = df_pre.copy()
            df_perm[self.x] = permuted_x

            try:
                stat = self.get_dependence(df_perm)
            except Exception:
                # ignore permutations that fail
                continue

            if stat is None or (isinstance(stat, float) and np.isnan(stat)):
                continue

            if abs(stat) >= obs_val:
                count += 1

        # p-value with +1 correction
        pval = (count + 1) / (n_permutations + 1)
        return float(pval)


class LinearRegressionCoefficientTTest(CiTests, LinearRegressionCoefficient):
    def __init__(self, x, y, cond_list=None, drop_na=False):
        super().__init__(x, y, cond_list, drop_na)

    # def get_dependence(self, df):
    #     # df = self._prepare_data(df)
    #     # X_data = df[[self.x] + self.cond_list].values
    #     # Y_data = df[self.y].values
    #     # reg = lr().fit(X_data, Y_data)
    #     dep = LinearRegressionCoefficient(self.x, self.y, self.cond_list, self.drop_na)
    #     res = dep.get_dependence(df)
    #     return res

    def get_pvalue(self, df):
        df = self._prepare_data(df)
        X_data = df[[self.x] + self.cond_list].values
        Y_data = df[self.y].values
        pval = fr(X_data, Y_data)[1][0]
        return pval


class FisherZTest(CiTests, PartialCorrelation):
    """
    Continuous conditional independence test using the Fisher Z-transform.
    Suitable for Gaussian data. Computes partial correlations and corresponding p-values.
    Reference: Spirtes et al., "Causation, Prediction, and Search".
    """

    def __init__(self, x, y, cond_list=None, drop_na=False):
        """
        Initialize the test with variables X, Y and optional conditioning set Z.
        :param x: str, name of first variable
        :param y: str, name of second variable
        :param cond_list: list of str, conditioning variables
        """
        super().__init__(x, y, cond_list, drop_na)

    # def get_dependence(self, df):
    #     """
    #     Compute the partial correlation between X and Y given Z.
    #     Returns a correlation coefficient r in [-1,1].
    #     """
    #     df = self._prepare_data(df)
    #     dep = PartialCorrelation(self.x, self.y, self.cond_list, self.drop_na)
    #     r = dep.get_dependence(df)
    #
    #     # list_nodes = [self.x, self.y] + self.cond_list
    #     # df = df[list_nodes]
    #     # a = df.values.T
    #     #
    #     # if len(self.cond_list) > 0:
    #     #     cond_list_int = [i + 2 for i in range(len(self.cond_list))]
    #     # else:
    #     #     cond_list_int = []
    #     #
    #     # correlation_matrix = np.corrcoef(a)
    #     # var = list((0, 1) + tuple(cond_list_int))
    #     # sub_corr_matrix = correlation_matrix[np.ix_(var, var)]
    #     #
    #     # if np.linalg.det(sub_corr_matrix) == 0:
    #     #     r = 1
    #     # else:
    #     #     inv = np.linalg.inv(sub_corr_matrix)
    #     #     r = -inv[0, 1] / np.sqrt(inv[0, 0] * inv[1, 1])
    #     return r

    def get_pvalue(self, df):
        """
        Compute the p-value for the partial correlation.
        Uses the Fisher Z-transform:
            z = 0.5 * ln((1+r)/(1-r))
            test statistic = sqrt(n - |Z| - 3) * |z|
        Returns a two-sided p-value.
        """
        df = self._prepare_data(df)
        r = self.get_dependence(df)
        # validate correlation
        if r is None or not np.isfinite(r):
            return np.nan

        # Effective sample size for Fisher Z
        n_eff = df.shape[0] - len(self.cond_list) - 3
        if n_eff <= 0:
            return np.nan

        # Clip r away from ±1 to avoid numerical blowups
        eps = 1e-12
        r = float(np.clip(r, -1 + eps, 1 - eps))

        z = 0.5 * np.log((1 + r) / (1 - r))
        test_stat = np.sqrt(n_eff) * abs(z)
        pval = 2 * (1 - norm.cdf(abs(test_stat)))
        return float(pval)


class GsqTest(CiTests, Gsq):
    """
    Discrete conditional independence test using the G² likelihood-ratio test.
    Reference: Spirtes et al., "Causation, Prediction, and Search".
    """

    def __init__(self, x, y, cond_list=None, drop_na=False):
        super().__init__(x, y, cond_list, drop_na)

    def get_pvalue(self, df):
        """
        Returns the p-value of the G² test.
        Degrees of freedom = (|X|-1)*(|Y|-1)*prod(|Z_i|) for each conditioning state.
        """
        df = self._prepare_data(df)
        tables = self._contingency_table(df)
        g2_stat = self.get_dependence(df)
        # Compute degrees of freedom
        df_total = 0
        for table in tables.values():
            r, c = table.shape
            df_total += (r - 1) * (c - 1)

        if df_total <= 0 or not np.isfinite(g2_stat):
            return np.nan

        pval = 1 - chi2.cdf(g2_stat, df_total)
        return float(pval)


class KernelPartialCorrelationTest(CiTests, KernelPartialCorrelation):
    """
    Kernel-based conditional independence test using the Hilbert-Schmidt Independence Criterion (HSIC).
    Suitable for nonlinear relationships and mixed data types. Uses permutation testing for p-value estimation.
    Reference: Zhang et al., "Kernel-based Conditional Independence Test and Application in Causal Discovery".
    """

    def __init__(self, x, y, cond_list=None, drop_na=False):
        super().__init__(x, y, cond_list, drop_na)

    def get_pvalue(self, df, n_permutations: int = 1000, seed: int = None):
        """Estimate a permutation p-value for the CMIh statistic using the
        generic permutation method implemented in `get_pvalue_by_permutation`.

        Note: this can be expensive; choose n_permutations accordingly.
        """
        # Delegate to the generic permutation-based p-value estimator
        raise NotImplementedError("CMIhTest relies on get_pvalue_by_permutation for p-value estimation. Call that method directly.")


class CIMhTest(CiTests, CMIh):
    """
    Conditional independence test based on the Maximal Information Coefficient (MIC).
    Suitable for continuous data. Uses permutation testing for p-value estimation.
    Reference: Reshef et al., "Detecting Novel Associations in Large Data Sets".
    """

    def __init__(self, x, y, cond_list=None, drop_na=False):
        super().__init__(x, y, cond_list, drop_na)

    # def get_dependence(self, df):
    #     dep = CMIh(self.x, self.y, self.cond_list, self.drop_na)
    #     res = dep.get_dependence(df)
    #     return res

    def get_pvalue(self, df, n_permutations: int = 1000, seed: int = None):
        """Estimate a permutation p-value for the CMIh statistic using the
        generic permutation method implemented in `get_pvalue_by_permutation`.

        Note: this can be expensive; choose n_permutations accordingly.
        """
        # Delegate to the generic permutation-based p-value estimator
        raise NotImplementedError("CMIhTest relies on get_pvalue_by_permutation for p-value estimation. Call that method directly.")
