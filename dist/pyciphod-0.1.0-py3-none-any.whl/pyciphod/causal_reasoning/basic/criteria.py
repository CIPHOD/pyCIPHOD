from pyciphod.utils.graphs.graphs import DirectedMixedGraph
from typing import Type, Optional, Set, Tuple, Iterable, FrozenSet
from pyciphod.utils.graphs import d_separation


def back_door_criterion(graph:DirectedMixedGraph, X: Iterable, Y: Iterable, Z: Iterable):
    """Back-door criterion: Z blocks all back-door paths from X to Y, and no node in Z is a descendant of X.
    Returns True if the criterion is satisfied.
    """
    Xs = _to_set(X)
    Ys = _to_set(Y)
    Zs = _to_set(Z)

    # Check that no node in Z is a descendant of X
    for z in Zs:
        if z in graph.get_descendants(z):
            return False

    # Check that Z blocks all back-door paths from X to Y
    for x in Xs:
        for y in Ys:
            if not d_separation(graph, {x}, {y}, Zs):
                return False

    return True


def front_door_criterion(graph, X, Y, Z):
    """Front-door criterion: Z intercepts all directed paths from X to Y, there is no back-door path from X to Z, and all back-door paths from Z to Y are blocked by X.
    Returns True if the criterion is satisfied.
    """
    Xs = _to_set(X)
    Ys = _to_set(Y)
    Zs = _to_set(Z)

    # Check that Z intercepts all directed paths from X to Y
    for x in Xs:
        for y in Ys:
            if nx.has_path(graph, x, y) and not any(nx.has_path(graph, x, z) and nx.has_path(graph, z, y) for z in Zs):
                return False

    # Check that there is no back-door path from X to Z
    for x in Xs:
        for z in Zs:
            if not d_separation(graph, {x}, {z}, set()):
                return False

    # Check that all back-door paths from Z to Y are blocked by X
    for z in Zs:
        for y in Ys:
            if not d_separation(graph, {z}, {y}, Xs):
                return False

    return True
